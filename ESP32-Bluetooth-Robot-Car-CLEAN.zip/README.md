# ESP32 Bluetooth Robot Car 🤖

Bluetooth-controlled robot car using ESP32 and L298N motor driver.

## Components
- ESP32-38PinWide
- L298N motor driver
- 4 DC geared motors
- 7–12 V DC power source
- Robot chassis
- Jumper wires

## ESP32 Pin Connections
| L298N | ESP32 |
|---|---:|
| IN1 | GPIO 12 |
| IN2 | GPIO 13 |
| IN3 | GPIO 27 |
| IN4 | GPIO 14 |
| ENA | GPIO 25 |
| ENB | GPIO 26 |

## Bluetooth
Device name: `ESP32_RC_Car`

Commands: `F` Forward, `B` Backward, `L` Left, `R` Right, `S` Stop.

## Files
- `ESP32-Bluetooth-Robot-Car.ino` — Arduino code
- `circuit.png` — circuit diagram
- `robot-car.jpg` — project photo
- `demo.mp4` — demonstration video

## Note
Verify your actual wiring and power arrangement before powering the robot.

⭐ If you find this project useful, consider starring the repository.
